﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Directum_Plugin.DTO
{
    public class UsersList
    {
        public List<User> Users { get; set; }
    }
}
